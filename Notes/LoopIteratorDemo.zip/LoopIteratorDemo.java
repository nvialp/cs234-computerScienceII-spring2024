/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.listdemo;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author CEHVAREE
 */
public class LoopIteratorDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LinkedList<String> staff = new LinkedList<>();
       
        
        staff.add("Diana");
        staff.add("Harry");
        staff.add("Romeo");
        staff.add("Tom");
        
        System.out.println("Our staff: ");
        System.out.println(staff);
        
        // For loop
//        System.out.println("## Traditional for loop using indices");
//        // slow, it needs to move to the location for every iteration
//        // not all data structures have indices (i.e., Sets)
//        for (int i=0; i<staff.size(); i++)
//        {   
//            System.out.println(staff.get(i));
//        }
        
        // foreach
        // uses an iterator behind the scenes
//        System.out.println("## Enhance foreach loop");
//        for (String name : staff)
//        {
//            System.out.println(name);
//        }
                
        // iterator
        System.out.println("## Iterator");
        for (ListIterator<String> iterator = staff.listIterator(); iterator.hasNext();)
        {
            System.out.println(iterator.next());
        }
    
        String target = "Romeo";

        // add an element
//        System.out.println();
//        System.out.println("Adding with an iterator");
//        
//        ListIterator<String> iterator2 = staff.listIterator();
//        while (iterator2.hasNext())
//        {
//            if (iterator2.next().equals(target))
//            {
//                iterator2.add(target);
//            }
//        }
//        System.out.println("Staff: " + staff);
        
        
        System.out.println("Adding with a for loop");
        for (int i=0; i<staff.size();i++)
        {
            if (staff.get(i).equals(target))
            {
                staff.add(target);
            }
        }
        System.out.println("Staff: " + staff);
        
    }
    
}
