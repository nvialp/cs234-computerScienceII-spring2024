/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.setdemo;
import java.util.HashSet;
import java.util.Set;
/**
 *
 * @author CEHVAREE
 */
public class SetOperations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Set<Integer> set1 = new HashSet<>();
       Set<Integer> set2 = new HashSet<>();
       Set<Integer> set3 = new HashSet<>();
       
       set1.add(1);
       set1.add(2);
       set1.add(3);
       set1.add(4);
       
       set2.add(2);
       set2.add(4);
       set2.add(6);
       
       set3.add(1);
       set3.add(4);
       
       
       System.out.println(set1);
       System.out.println(set2);
       System.out.println(set3);
       
        
        // union
        Set<Integer> union = new HashSet<>(set1);
        union.addAll(set2);
        System.out.println("Union: " + union);
        

        // intersection
        Set<Integer> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);
        System.out.println("Intersection: " + intersection);
        
        // difference
        Set<Integer> difference = new HashSet<>(set1);
        difference.removeAll(set2);
        System.out.println("Difference: " + difference);
        
        // subset
        System.out.println(set1.containsAll(set3));
    }
    
}
