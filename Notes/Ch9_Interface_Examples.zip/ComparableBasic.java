/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Source: tutorials.jenkov.com/java-collection/comparable.html
 */
package com.mycompany.sec06;

/**
 *
 * @author CEHVAREE
 */
public class ComparableBasic {
    
    public static void main(String[] args) {
        Integer A = Integer.valueOf(45);
        Integer B = Integer.valueOf(99);
        Integer C = Integer.valueOf(45);
        
        int comparisonAB = A.compareTo(B);
        int comparisonBA = B.compareTo(A);
        int comparisonAC = A.compareTo(C);
        
        System.out.println(comparisonAB);
        System.out.println(comparisonBA);
        System.out.println(comparisonAC);
    }
}
