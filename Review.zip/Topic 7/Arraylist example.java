/******************************************************************************

Array list

*******************************************************************************/
import java.util.ArrayList;

public class Main {
  public static void main(String[] args) {
    ArrayList<String> teams = new ArrayList<String>();
    
    teams.add("Lakers");
    teams.add("Warriors");
    teams.add("Rockets");
    teams.add("Spurs");
    
    System.out.printf("There are %d teams\n", teams.size());
    System.out.printf("The first team is %s\n", teams.get(0));
    for (String team : teams)
    {
        System.out.println(team);
    }
    
    System.out.println("Let's remove a team");
    teams.remove(2);
    System.out.printf("Now, there are %d teams\n", teams.size());
    for (String team : teams)
    {
        System.out.println(team);
    }
    
  }
}
