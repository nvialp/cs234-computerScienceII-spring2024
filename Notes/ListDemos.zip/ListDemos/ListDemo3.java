/*
 * https://beginnersbook.com/2013/12/linkedlist-in-java-with-example/
 */
package com.mycompany.listdemo;
import java.util.*;
/**
 *
 * @author CEHVAREE
 */
public class ListDemo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Declare a LinkedList
        LinkedList<String> linkedlist = new LinkedList<>();
        
        // add(String Element) is used for adding
        // the elements to the linked list
        
        linkedlist.add("item1");
        linkedlist.add("item5");
        linkedlist.add("item3");
        linkedlist.add("item6");
        linkedlist.add("item2");
        
        // Display linked list content
        System.out.println("Linkedlist content: " + linkedlist);
        
        // Add first and last element
        linkedlist.addFirst("First item");
        linkedlist.addLast("Last item");
        System.out.println("Linkedlist after addition: " + linkedlist);  
        
        // How to set and get values
        String firstvar = linkedlist.get(0);
        System.out.println("First element: " + firstvar);
        
        linkedlist.set(0, "Changed first item");
        String firstvar2 = linkedlist.get(0);
        System.out.println("First element after update: " + firstvar2);
        
        // Remove first and last element
        linkedlist.removeFirst();
        linkedlist.removeLast();
        System.out.println("Linkedlist after deletion of first and last "
                + "element: " +linkedlist);
        
        // Add a position and remove from a position
        linkedlist.add(0, "Newly added item");
        linkedlist.remove(2);
        System.out.println("Final content: " + linkedlist);
        
    }
}
