/******************************************************************************

constants

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    final double BOTTLE_VOLUME = .500; //ml
	    
	    double totalVolumne;
	    double bottles = 3;
	    
	    totalVolumne = bottles * .500; // What does this number represent?
	    
	    totalVolumne = bottles * BOTTLE_VOLUME; // This is easier to understand
	    
		System.out.println(totalVolumne);
	}
}
