/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Source: https://www.geeksforgeeks.org/interfaces-in-java
 */
package com.mycompany.sec06;

interface Vehicle
{
    // all methods are abstract
    void changeGear(int a);
    void speedUp(int a);
    void applyBrakes(int a);
}


class Bicycle implements Vehicle
{
    private int speed;
    private int gear;
    
    public void changeGear(int newGear)
    {
        gear = newGear;
    }
    
    public void speedUp(int increment)
    {
        speed = speed + increment;
    }
    
    public void applyBrakes(int decrement)
    {
        speed = speed - decrement;
    }
    
    public void printStates()
    {
        System.out.println("speed: " + speed +
                            " gear: " + gear);
    }
}


class Bike implements Vehicle
{
    private int speed;
    private int gear;
    
    public void changeGear(int newGear)
    {
        gear = newGear;
    }
    
    public void speedUp(int increment)
    {
        speed = speed + increment;
    }
    
    public void applyBrakes(int decrement)
    {
        speed = speed - decrement;
    }
    
    public void printStates()
    {
        System.out.println("speed: " + speed +
                            " gear: " + gear);
    }
}
public class BikeInterfaceDemo {
    public static void main(String[] args) {
        
        Bicycle bicycle = new Bicycle();
        bicycle.changeGear(2);
        bicycle.speedUp(3);
        bicycle.applyBrakes(1);
        
        System.out.println("Bicycle present state is");
        bicycle.printStates();
        
        
        Bike bike = new Bike();
        bike.changeGear(1);
        bike.speedUp(4);
        bike.applyBrakes(3);
        
        System.out.println("Bike present state is");
        bike.printStates();
        
    }
}
