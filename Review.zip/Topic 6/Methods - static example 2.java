/******************************************************************************

Example of static Method 


*******************************************************************************/
public class Main
{
    
    public static int sum(int num1, int num2){
        return num1 + num2;
    }
    
	public static void main(String[] args) {
		System.out.println("Sum: " + sum(1,2));
	}
}
