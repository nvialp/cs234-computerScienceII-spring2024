/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * geeksforgeeks.com/stack-class-in-java/
 */
package com.mycompany.stackqueuepriorityqueue;
import java.util.*;
/**
 *
 * @author CEHVAREE
 */
public class StackDemo2 {

    static void stack_push(Stack<Integer> stack)
    {
        for (int i=0; i<5; i++)
        {
            stack.push(i);
        }
    }
    
    
    static void stack_pop(Stack<Integer> stack)
    {
        System.out.println("Pop operation");
        for (int i=0; i<5; i++)
        {
            int n = stack.pop();
            System.out.println(n);
        }
    }
    
    
    static void stack_peek(Stack<Integer> stack)
    {
        int element = stack.peek();
        System.out.println("Element on top: " + element);
    }
    
    static void stack_search(Stack<Integer> stack, int element)
    {
        int position = stack.search(element);
        if (position == -1)
        {
            System.out.println("Element " + element + " not found");
        }
        else{
            System.out.println("Element " + element + " is in position: " + position);
        }
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        
        stack_push(stack);
        stack_pop(stack);
        stack_push(stack);
        stack_peek(stack);
        stack_search(stack, 2);
        stack_search(stack, 6);
    }
    
}
