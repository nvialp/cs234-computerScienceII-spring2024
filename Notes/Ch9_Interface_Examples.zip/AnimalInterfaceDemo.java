/* Java does not support multiple inheritance.
 * To prevent ambiguity. (Diamond problem)
 * Example of the use of interfaces to have multiple inheritance
 * https://www.tutorialspoint.com/multiple-inheritance-by-interface-in-java
 */
package com.mycompany.sec06;

interface AnimalEat {
    String GREETINGS = "EEEEE";
    void eat();
}

interface AnimalTravel {
    void travel();
}


class Animal implements AnimalEat, AnimalTravel {
    
    public void eat()
    {
        System.out.println("Animal is eating");
    }

    public void travel()
    {
        System.out.println("Animal is traveling");
    }
}


public class AnimalInterfaceDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal a = new Animal();
        a.eat();
        a.travel();
        System.out.println(a.GREETINGS);
    }
    
}
