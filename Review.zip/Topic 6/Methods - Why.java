/******************************************************************************

Why do we need methods?
(Example of method)

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static int readIntBetween(int low, int high)
    {
        Scanner in = new Scanner(System.in);
        int input;
        
        // Read value
        do{
            System.out.printf("Enter a value between %d and %d:", low, high);
            input = in.nextInt();
        }while (input < low || input > high);
        return input;
    }
    
   public static void main(String args[]) 
   {
        int hours = readIntBetween(0,23);
        int minutes = readIntBetween(0, 59);
   }
}
