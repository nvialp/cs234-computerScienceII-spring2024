/******************************************************************************

How many years to reach Target amount?

*******************************************************************************/
public class Main
{
   public static void main(String args[]) 
   {
       
       final double RATE = 10;
       final double INITIAL_BALANCE = 10000;
       final double TARGET = 15000;
       
       double balance = INITIAL_BALANCE;
       int year = 0;
       
       while (balance < TARGET)
       {
           year++;
           balance = balance * (1+(RATE/100));
        //   System.out.println("year: " + year + " ");
        //   System.out.printf("balance: %.1f", balance);
       }
       
       System.out.printf("\nTarget reached in %d years",year);
       
   }
}
