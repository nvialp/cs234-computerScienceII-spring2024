/******************************************************************************

Java example for boolean operations (between)

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
		System.out.println("Write the age for Emma: ");
		int emma = in.nextInt();
		System.out.println("Write the age for John: ");
		int john = in.nextInt();
		System.out.println("Write the age for Sara");
		int sara = in.nextInt();
		
		System.out.println("Is Johns' age between Emma's and Sara's?");
		System.out.println(emma<john && john < sara);
	}
}
