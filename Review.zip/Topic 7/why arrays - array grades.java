/******************************************************************************

why do we need arrays? 
array of student grades, avg

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		double[] grades = {4.8, 8.3, 7.6, 8.0, 9.5};

		double average = 0.0;
		
		for (int idx=0; idx<grades.length; idx++)
		{
		    average = average + grades[idx];
		}
		average = average / grades.length;
		
		System.out.format("Average: %.2f", average);
		
		
	}
}
