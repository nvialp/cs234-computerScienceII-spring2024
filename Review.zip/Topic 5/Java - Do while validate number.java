/******************************************************************************

Validate input

*******************************************************************************/
import java.util.Scanner;

public class Main
{
   public static void main(String args[]) 
   {
        Scanner in = new Scanner(System.in);
        int value;
        
        do
        {
            System.out.println("Enter an integer < 10:");
            value = in.nextInt();
        }
        while (value >= 10);
        System.out.println("The value was " + value);
   }
}

