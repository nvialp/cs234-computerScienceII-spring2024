/******************************************************************************

partially filled array

*******************************************************************************/
public class Main
{
    public static int n = 0;    //This variable cannot be local. Can you see why?
    
    public static void addElement(double[] grades, double grade)
    {
        if (n < grades.length)
        {   
            System.out.println("Adding grade: " + grade );
            grades[n] = grade;
            n = n + 1;
        }
        else
        {
            System.out.println("The array is full");
        }
    }
    
    public static double average(double[] grades)
    {
        double total = 0;
        for (int i=0; i<n; i++)
        {
            total = total + grades[i];
        }
        return total / grades.length; // Is the average correct?
        // return total / n;
    }
    
	public static void main(String[] args) {
		
		double[] grades = new double[10];
		
		addElement(grades, 9.8);
		addElement(grades, 7.5);
		addElement(grades, 6.7);
        
        System.out.println("The grades are:");
		for (double grade : grades)
		{
		    System.out.println(grade);
		}
		
		System.out.printf("There are: %d grades\n", n);
		System.out.printf("The average is: %.2f", average(grades));
	}
}



