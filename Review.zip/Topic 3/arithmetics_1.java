/******************************************************************************

arithmetics

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		int grade1 = 8;
		int grade2 = 7;
		int grade3 = 8;
		
		int avg = (grade1 + grade2 + grade3) / 3;
		
		System.out.println(avg);
	}
}
