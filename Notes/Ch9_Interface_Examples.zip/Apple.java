/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Source: https://dzone.com/articles/java-comparable-interface-in-five-minutes
 */
package com.mycompany.sec06;

/**
 *
 * @author CEHVAREE
 */
public class Apple implements Comparable<Apple>{
    private int weight;
   
    public Apple(int weight)
    {
        this.weight = weight;
    }
    
    public int compareTo(Apple other)
    {
        if (this.weight < other.weight)
        {
            return -1;
        }
        if (this.weight == other.weight)
        {
            return 0;
        }
        return 1;
    }
    
    public static void main(String[] args) {
        Apple a1 = new Apple(3);
        Apple a2 = new Apple(4);
        
        int compareApples = a1.compareTo(a2);
        System.out.println(compareApples);
        
    }
}
