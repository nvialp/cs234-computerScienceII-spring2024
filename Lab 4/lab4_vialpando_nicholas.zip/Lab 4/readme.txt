CS 234 - LAB COMPILING INSTRUCTIONS

1. Open cmd line or terminal.

2. Change directory to file location: 
	cd :C\<directory path to file>

3. Run java compiler:
	javac <filename>.java

4. The compiler will the create a .class file.

5. Run the .class file:
	java <filename>  