/******************************************************************************

2D Arryas

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    
	    int[][] counts = {
                            { 1, 0, 1 },    // row 1
                            { 1, 1, 0 },    // row 2
                            { 0, 0, 1 },    // row 3
                            { 1, 0, 0 }     // row 4
	                    };
	    int rows = counts.length;
	    int columns = counts[0].length;
	    
	    System.out.printf("2D Array with %d rows and %d columns",
	                        rows, columns);
	
	}
}

