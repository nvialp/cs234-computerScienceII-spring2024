/******************************************************************************

Example of sentinel values

*******************************************************************************/
import java.util.Scanner;  

public class Main
{
	public static void main(String[] args) {
	    Scanner in = new Scanner(System.in);
	    double sum = 0;
	    int count = 0;
	    double salary = 0;
	    boolean sentinel = true;
	    System.out.println("Enter salaries (negative to finish):");
	    while (sentinel == true)
	    {
	        salary = in.nextDouble();
	        if (salary < 0)
	            sentinel = false;
	        else
	        {
	            sum = sum + salary;
	            count++;
	        }
	       
	    }
	    if (count > 0)
	    {
	        double average = sum / count;
	        System.out.format("Avg salary: %.2f" , average);
	    }
	    else
	    {
	        System.out.println("No data");
	    }
	}
}
