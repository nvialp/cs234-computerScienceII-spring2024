/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.listdemo;
import java.util.LinkedList;
import java.util.ListIterator;
/**
 *
 * @author CEHVAREE
 */
public class ListDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        LinkedList<String> staff = new LinkedList<>();
       
        
        staff.add("Diana");
        staff.add("Harry");
        staff.add("Romeo");
        staff.add("Tom");
        
        System.out.println("Our staff: ");
        System.out.println(staff);
        
        ListIterator<String> iterator = staff.listIterator();
        iterator.next(); 
        iterator.next();
        
        iterator.add("Juliet");
        iterator.add("Nina");
        

        System.out.println(staff);
        
        iterator.next();
        iterator.remove();
        System.out.println(staff); 
       
    }
    
}
