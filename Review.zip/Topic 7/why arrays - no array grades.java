/******************************************************************************

why do we need arrays? 
student grades, avg

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		double gradeS1 = 4.8;
		double gradeS2 = 8.3;
		double gradeS3 = 7.6;
		double gradeS4 = 8.0;
		double gradeS5 = 9.5;
		
		double average = (gradeS1 + gradeS2 + gradeS3 + gradeS4 + gradeS5) / 5;
		
		System.out.format("Average: %.2f", average);
		
		
	}
}
