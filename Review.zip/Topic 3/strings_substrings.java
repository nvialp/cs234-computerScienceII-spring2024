/******************************************************************************

Example of strings

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		String str = new String("Today is a beautiful day to code in Java");
		System.out.println("Original sentence: " + str);
		
		System.out.println("Substring starting from index 10:");
		System.out.println(str.substring(10));
		
		System.out.println("Substring starting from index 10 and ending at inedx 20:");
		System.out.println(str.substring(10, 20));
		
	}
}
