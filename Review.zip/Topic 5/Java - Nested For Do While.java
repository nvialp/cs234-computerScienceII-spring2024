/******************************************************************************
Nested loops
Ask 5 positive numbers

*******************************************************************************/
import java.util.Scanner;  


public class Main
{
	public static void main(String[] args) {
		int numbers = 5;
		Scanner in = new Scanner(System.in);
		for(int i=1; i<=numbers; i++)
		{
		    int num;
		    do{
		        System.out.println("Write a positive number");
		        num = in.nextInt();
		    }while(num < 1);
		    
		    System.out.println("Number: " + num);
		}
	}
}
