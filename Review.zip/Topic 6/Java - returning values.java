/******************************************************************************

Returning values

*******************************************************************************/
public class Main
{
    // public static int areaTriangle(double base, double height)
    public static double areaTriangle(double base, double height)
    {
        double area = (base* height)/2;
        return area;
    }
    
   public static void main(String args[]) 
   {
       double base = 3.5;
       double height = 4.2;
      double area = areaTriangle(base, height);
    //   int area = areaTriangle(base, height);
       System.out.printf("The are of the triangle is %.3f",area);
   }
}