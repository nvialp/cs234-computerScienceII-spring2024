/******************************************************************************

How much money in X years?

*******************************************************************************/
public class Main
{
   public static void main(String args[]) 
   {
       
       final double RATE = 10;
       final double INITIAL_BALANCE = 10000;
       final int TARGET_YEARS =5;
       
       double balance = INITIAL_BALANCE;
       
       
       for (int year = 1; year <= TARGET_YEARS; year++)
       {
           balance = balance * (1+(RATE/100));
          System.out.printf("%d %.2f\n", year,balance);
       }
       
       System.out.printf("After %d years I have $%.2f",TARGET_YEARS, balance);
   }
}
