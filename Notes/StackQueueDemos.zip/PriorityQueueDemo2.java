
package com.mycompany.stackqueuepriorityqueue;
import java.util.PriorityQueue;
import java.util.Queue;

/**
   This program simulates a print queue. Note that documents are printed
   in the same order as they are submitted. 
*/
public class PriorityQueueDemo2
{
   public static void main(String[] args)
   {
      Queue<String> jobs = new PriorityQueue<>(); 
      jobs.add("Level 5: Expense Report #1");
      jobs.add("Level 3: Meeting Memo");
      jobs.add("Level 1: Purchase Order #1");   // From the boss
      jobs.add("Level 5: Expense Report #2");
      jobs.add("Level 2: Weekly Report");
      
      while (jobs.size() > 0)
      {
         System.out.println("Printing " + jobs.remove());
      }
   }
}

