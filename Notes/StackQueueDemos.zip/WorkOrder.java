/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.stackqueuepriorityqueue;

/**
 *
 * @author CEHVAREE
 */
public class WorkOrder implements Comparable
{
    private int priority;
    private String description;
    
    public WorkOrder(int aPriority, String aDescription)
    {
        priority = aPriority;
        description = aDescription;
    }
    
    public String toString()
    {
        return "priority="+ priority + ", description=" + description;
    }
    
    @Override
    public int compareTo(Object otherObject) 
    {
        WorkOrder other = (WorkOrder) otherObject;
        if(this.priority < other.priority) {return -1;}
        else if (this.priority > other.priority) {return 1;}
        else {return 0;}
        
    }
}
