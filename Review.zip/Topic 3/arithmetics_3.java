/******************************************************************************

arithmetics 3

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		int grade1 = 8;
		int grade2 = 7;
		int grade3 = 8;
		
		double avg = (double)(grade1 + grade2 + grade3) / 3;
		
		System.out.println(avg);
	}
}
