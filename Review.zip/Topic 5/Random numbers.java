/******************************************************************************

Random numbers

*******************************************************************************/
import java.util.Scanner;
public class Main
{
   public static void main(String args[]) 
   {
        Scanner in = new Scanner(System.in);
        final int LOWER = 1;
        final int UPPER = 100;
        
        for (int i=1; i<10; i++)
        {
            int number = (int)(Math.random() * (UPPER - LOWER + 1)) + LOWER;
            System.out.println("Random number: " + number);
        }
   }
}
