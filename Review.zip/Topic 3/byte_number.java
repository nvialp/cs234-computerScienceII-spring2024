/******************************************************************************

Example: Byte number

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		byte num = 153;
		System.out.println(num);
	}
}
