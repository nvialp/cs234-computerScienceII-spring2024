/******************************************************************************

Arrays and Methods

*******************************************************************************/
public class Main
{
    public static void doubleValues(double[] arr)
    {
        for (int i=0; i < arr.length; i++)
        {
            arr[i] = 2 * arr[i];
        }
    }
    
    public static void doubleValues(double val)
    {
        val = 2 * val;
    }
    
    public static void main(String[] args)
    {
    	double[] values = new double[3]; 
    	
    	double val = 3;
    	doubleValues(val);
    	System.out.println(val);
    		
        values[0] = 1.5; 
    	values[1] = 2.4; 
    	values[2] = 5.2; 
    	
    	doubleValues(values);
    	
    	for (double value:values)
    		System.out.println(value);		 
	   } 
}

