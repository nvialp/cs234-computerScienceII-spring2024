/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * javapoint.com/java-map
 */
package com.mycompany.mapdemo;
import java.util.*;

/**
 *
 * @author CEHVAREE
 */
public class MapDemoEntrySet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(100, "Eduardo");
        map.put(101, "Luis");
        map.put(102, "John");
        
        for (Map.Entry m : map.entrySet())
        {
            System.out.println(m.getKey() + " " + m.getValue());
        }
    }
    
}
