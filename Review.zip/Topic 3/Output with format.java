/******************************************************************************

printf examples


*******************************************************************************/
class Main {
    public static void main(String[] args) {
    	
    	String sAmount = "Amount ";
    	String sAge = "Age ";
    	System.out.printf("We are printing the %s and the %s\n", sAmount, sAge);
    	
    	double amount = 24.5;
        System.out.printf("%.2f\n",amount);
        
        int age = 24;
        System.out.printf("%5d\n",age);
        
        System.out.printf("%s: %.2f %s: %d\n", sAmount, amount, sAge, age);
    }
}




