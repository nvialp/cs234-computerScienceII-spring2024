/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.setdemo;

/**
 *
 * @author CEHVAREE
 */
public class hashCodeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s1 = "Ashley";
        String s2 = "Eduardo";
        String s3 = "Bob";
        String s4 = "Ashley";
        Integer s5 = 100;
      
        int bucketSize = 3;
        
        System.out.println("Show he hash codes");
        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(s3.hashCode());
        System.out.println(s4.hashCode());
        System.out.println(s5.hashCode());
        
        System.out.println("Show the buckets");
        System.out.println(s1.hashCode()% bucketSize);
        System.out.println(s2.hashCode()% bucketSize);
        System.out.println(s3.hashCode()% bucketSize);
        System.out.println(s4.hashCode()% bucketSize);
        System.out.println(s5.hashCode()% bucketSize);
    }
    
}
