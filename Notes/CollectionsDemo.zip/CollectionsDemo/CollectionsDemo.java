/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.collectionsdemo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeSet;

/**
 *
 * @author CEHVAREE
 */
public class CollectionsDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Working with an ArrayList");
        workwith(new ArrayList<>());
        System.out.println("Working with a TreeSet");
        workwith(new TreeSet<>());
    }
    
    public static void workwith(Collection<String> coll){
        coll.add("Harry");
        coll.add("Sally");
        coll.add("Fredd");
        coll.add("Wilma");
        coll.add("Harry");
        System.out.println(coll);
        
        System.out.print("Removing Harry and Tom: ");
        System.out.print(coll.remove("Harry") + " ");
        System.out.println(coll.remove("Tom"));
        
        System.out.print("Looking for Harry and Sally: ");
        System.out.print(coll.contains("Harry") + " ");
        System.out.println(coll.contains("Sally"));
        
        for (String s:coll)
        {
            System.out.println(s);
        }
    }
    
}
