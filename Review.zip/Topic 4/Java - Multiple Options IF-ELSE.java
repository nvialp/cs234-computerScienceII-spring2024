/******************************************************************************

multiple options IF-ELSE

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    
    	String digitName;
    	int digit = 0;
    	
        if (digit == 1) { digitName = "one"; }
        else if (digit == 2) { digitName = "two"; }
        else if (digit == 3) { digitName = "three"; }
        else if (digit == 4) { digitName = "four"; }
        else if (digit == 5) { digitName = "five"; }
        else if (digit == 6) { digitName = "six"; }
        else if (digit == 7) { digitName = "seven"; }
        else if (digit == 8) { digitName = "eight"; }
        else if (digit == 9) { digitName = "nine"; }
        else { digitName = ""; }
        
        System.out.println("The digit is:"+ digitName);
	}
}




