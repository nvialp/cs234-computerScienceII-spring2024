/******************************************************************************

arithmetics unary operators

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		int a = 100;
		
		System.out.println("a++: " + a++);
		System.out.println("a--: " + a--);
		System.out.println("++a: " + (++a));
		System.out.println("--a++: " + (--a));
	}
}
