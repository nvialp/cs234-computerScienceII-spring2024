/******************************************************************************
 
 Example of array initialization

*******************************************************************************/
public class Main
{
    
	public static void main(String[] args) {
		
		int[] values_int;
		//System.out.println(values);
		
		values_int = new int[10];
		System.out.println(values_int); //What is that number??
		
		System.out.println(values_int[0]);
		
		double[] values_double = new double[10];
		System.out.println(values_double); //What is that number??
		
		System.out.println(values_double[0]);
		
		
		String[] values_str = new String[10];
		System.out.println(values_str); //What is that number??
		
		System.out.println(values_str[0]);
		values_str[0] = "Hello";
	}
}
