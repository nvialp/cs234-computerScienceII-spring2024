/******************************************************************************

basic Substring

https://www.w3schools.com/java/java_ref_string.asp

*******************************************************************************/
public class Main{
   public static void main(String args[]) {
       String str= "Today is a beautiful day to code in Java";
       System.out.println("Original sentence: " + str);
       System.out.println("Size: " + str.length());
       
       System.out.println("Substring starting from index 10:");
       System.out.println(str.substring(10));
       System.out.println("Substring starting from index 10 and ending at 20:");
       System.out.println(str.substring(10, 20));
       
       String[] words = str.split(" ");
       int idx = 0;
       for (String w:words)
       {
           System.out.println(idx + " " + w);
           idx++;
       }
       
       System.out.println(str.contains("Java"));
       
       System.out.println(str.replace("beautiful", "great"));
       System.out.println(str);
   }
}


