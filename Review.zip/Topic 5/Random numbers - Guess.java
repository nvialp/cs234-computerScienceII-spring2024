/******************************************************************************

Random numbers

*******************************************************************************/
import java.util.Scanner;
public class Main
{
   public static void main(String args[]) 
   {
        Scanner in = new Scanner(System.in);
        final int LOWER = 1;
        final int UPPER = 10;
        
        int number = (int)(Math.random() * (UPPER - LOWER + 1)) + LOWER;
        System.out.println(number);
        int guess;
        
        do{
            System.out.printf("Guess a number between %d and %d:", LOWER, UPPER);
            guess = in.nextInt();
        }while (guess != number);
        System.out.println("Nice, the hidden number was " + number);
   }
}

