/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;

import java.io.*;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class Person
{
    private String name;
    private String country;
    private int height;
    
    public Person(String name, String country, int height)
    {
        this.name = name;
        this.country = country;
        this.height = height;
    }
    
    public String getName()
    {
        return this.name;
    }

    public String getCountry() {
        return country;
    }

    public int getHeight() {
        return height;
    }
    
    
    
    public String toString()
    {
        return "\tName: " + this.name + 
                ", Country: " + this.country +
                ", Height: " + this.height;
    }

}


/**
 *
 * @author CEHVAREE
 */
public class ReadFileMapPerson {

    /**
     * Method to add a new element to the Directory
     * The key is the name, the value is an object Person
     * @param directory
     * @param file
     */
    public static void addToDirectory(Map directory, String file) throws FileNotFoundException, IOException
    {
        String line = "";
        BufferedReader br = new BufferedReader(new FileReader(file));
        while((line=br.readLine())!= null)
        {
            String[] person = line.split(",");
            System.out.println("[INFO] Adding to the directory:");
            System.out.println("\t"+person[0]+","+person[1]+","+person[2]);
            
            directory.put(person[0], new Person(person[0], 
                                                person[1],
                                                Integer.parseInt(person[2])));
        }
    }
    
    /*
    * Method to print the whole directory
    * @param directory 
    */
    public static void printDirectory(Map directory)
    {
        System.out.println("\n[INFO] Printing the Directory"); 
        for (Object key : directory.keySet())
        {
            Person value = (Person) directory.get(key);
            System.out.println(value);
        }
    }
    
    public static void searchDirectory(String name, Map directory)
    {
        System.out.println("\n[INFO]Searching for: " + name);
        
        if (directory.containsKey(name))
        {
            System.out.println("\t"+directory.get(name));
        }
        else
        {
            System.out.println("\t[INFO]This name does not exist.");
        }      
    }
    
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
       
        Map<String, Person> directory = new HashMap<>();
        addToDirectory(directory, "data.csv");
        printDirectory(directory);
        searchDirectory("John", directory);
        searchDirectory("No name", directory);
    }
}
