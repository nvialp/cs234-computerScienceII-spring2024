/******************************************************************************

Why do we need methods?
(Example of no methods)

*******************************************************************************/
import java.util.Scanner;
public class Main
{
   public static void main(String args[]) 
   {
        Scanner in = new Scanner(System.in);
        int hours;
        
        // Read Hours
        do{
            System.out.printf("Enter a value between 0 and 23:");
            hours = in.nextInt();
        }while (hours < 0 || hours > 23);
        
        // Read minutes
        int minutes;
        do{
            System.out.printf("Enter a value between 0 and 59:");
            minutes = in.nextInt();
        }while (minutes < 0 || minutes > 59);
   }
}