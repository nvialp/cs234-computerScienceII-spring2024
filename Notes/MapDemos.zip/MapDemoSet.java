/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;
import java.util.*;
/**
 *
 * @author CEHVAREE
 */
public class MapDemoSet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Random ran = new Random();
        Map<String, Set<Integer>> map = new HashMap<>();
        String keys[] = {"apple", "orange", "grape"};
        for (String key : keys)
        {
            Set<Integer> integers = new HashSet<>();
            for (int i = 0; i<10; i++)
            {
                integers.add(ran.nextInt(9)+1);
            }
            map.put(key, integers);
        }
        System.out.println(map.toString());
        
        //
        Set<String> keySet = map.keySet(); 
        for (String key : keySet)
         {
             Set<Integer> value = map.get(key);
             System.out.println(key + ":");
             for (Integer number : value)
             {
                 System.out.println("\t"+number);
             }
         }
    }
}
