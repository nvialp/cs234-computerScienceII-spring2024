/******************************************************************************

Example 50 M

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int fiftyMillion = 50_000_000;
		System.out.println(100 * fiftyMillion); // Expected 5 000 000 0000
	}
}
