/******************************************************************************

method, modify non-primitive

*******************************************************************************/
public class Main
{
    void printGreeting(String greeting, boolean leaving)
    //static void printGreeting(String greeting, boolean leaving)
    {
        if (leaving == true)
        {
            greeting = greeting.replace("Hello", "Bye");
        }
        System.out.println(greeting);
    }
    
    
	public static void main(String[] args) {
	   // Main m = new Main();
	   String motd = "Hello, nice to meet you!";
	   // m.printGreeting(motd, true);
	    printGreeting(motd, false);   
	}
}

