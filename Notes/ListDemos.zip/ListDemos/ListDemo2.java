/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.listdemo;
import java.util.LinkedList;
import java.util.ListIterator;
/**
 *
 * @author CEHVAREE
 */
public class ListDemo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        LinkedList<String> staff = new LinkedList<>();
       
        staff.add("Diana");
        staff.add("Harry");
        staff.add("Romeo");
        staff.add("Tom");
        
        System.out.println("Our staff: ");
        System.out.println(staff);
        
        staff.add(2,"Juliet");
        staff.add(3, "Nina");

        System.out.println(staff);

        staff.remove(4);
        System.out.println(staff); 
        System.out.println("It should be [Diana, Harry, Juliet, Nina, Tom]");
        
        staff.remove();
        System.out.println(staff);
       
    }
    
}
