/******************************************************************************

Example accepted array types

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		int[] int_array = new int[10];
		
		int_array[0] = 1;
		int_array[1] = 2;
		
		int_array[2] = 4.0;
		
	}
}
