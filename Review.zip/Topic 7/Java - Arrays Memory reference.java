/******************************************************************************

Example Array and memory reference

*******************************************************************************/
public class Main
{
    public static void main(String[] args)
    {
    	String[] teams; 
    	teams = new String[5]; 
    		
    	teams[0] = "Lakers"; 
    	teams[1] = "Warriors"; 
    	teams[2] = "Rockets"; 
    	teams[3] = "Spurs"; 
    	teams[4] = "Celtics"; 
        
        String[] cities = teams;
        cities[2] = "Houston";
        
    	for (int i = 0; i < teams.length; i++) 
    		System.out.println("Team at index " + i + " : "+ teams[i]);		 
    		
    // 	System.out.println(teams);
    // 	System.out.println(cities);
	} 
}

