/******************************************************************************

Methods, modify objects

*******************************************************************************/
public class Main
{
    static void makeDouble(double[] list, int idx)
    {
        if (idx > list.length)
        {
            System.out.println("Index out of boundaries");
        }
        list[idx-1] = list[idx-1]*2;
        
    }
    
    
	public static void main(String[] args) {
	    
	    //Main m = new Main();
		double[] array = {1.4, 3.6, 9.6, 2.6};
		for (double n : array)
		{
		    System.out.println(n);
		}
		//m.makeDouble(array);
		System.out.println("-------");
		makeDouble(array, 4);
		for (double n : array)
		{
		    System.out.println(n);
		}
	}
}
