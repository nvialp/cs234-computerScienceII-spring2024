/******************************************************************************

Scope of variables

*******************************************************************************/
public class Main
{
    public static double addTax(double price, double rate)
    {
        double tax = price * rate / 100;
        price = price + tax; // Has no effect outside the method
        System.out.println("Price inside method: " + price);
        return tax;
    }
    
	public static void main(String[] args) {
		
		double price = 10.0;
        addTax(price, 7.5); // Does not modify total
        System.out.println("Price outside method: " + price);
	}
}
