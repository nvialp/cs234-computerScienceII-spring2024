public class Main
{
   public static void main(String args[]) 
   {
        int rows = 3;
        int columns = 4;
        
        for (int i=0; i<=rows; i++)
        {
            for (int j=0; j<=columns; j++)
            {
                System.out.printf("(%d,%d)",i,j);
            }
            System.out.println();
        }
   }
}

