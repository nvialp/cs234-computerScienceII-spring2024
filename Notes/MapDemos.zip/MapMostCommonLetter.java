/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;
import java.util.*;
/**
 *
 * @author CEHVAREE
 */
public class MapMostCommonLetter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<String, TreeSet<String>> initialsMap = new TreeMap<>();
        
        add(initialsMap, "ants");
        add(initialsMap, "and");
        add(initialsMap, "bats");
        add(initialsMap, "are");
        add(initialsMap, "everywhere");
        add(initialsMap, "bee");
        
        System.out.println(initialsMap);
        
        
        Set<String> keySet = initialsMap.keySet(); 
        for (String key : keySet)
         {
             Set<String> value = initialsMap.get(key);
             System.out.println(key + ":" + value.size());
         }
    }
    
    public static void add(Map<String, TreeSet<String>> map, String word)
    {
        String initial = word.substring(0,1);
        // Check if letter is already in the map
        TreeSet<String> words = map.get(initial);
        if (words == null)
        {
            words = new TreeSet<>();
            map.put(initial, words);
        }
        words.add(word);
     }
    
}
