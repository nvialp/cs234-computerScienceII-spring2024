/******************************************************************************

float number

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		float num = 19.98;
		System.out.println(num);
	}
}
