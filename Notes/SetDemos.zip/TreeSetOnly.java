/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.setdemo;
import java.util.Set;
import java.util.TreeSet;
/**
 *
 * @author CEHVAREE
 */
public class TreeSetOnly {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic he
        Set<Integer> set = new TreeSet<>();
        set.add(24);
        set.add(66);
        set.add(12);
        set.add(15);
        set.add(66);
        
        System.out.println(set);
    }
    
}
