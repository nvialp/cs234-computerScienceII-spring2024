/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * Source: https://codejava.net/java-core/collections/sorting-arrays-examples-with-comparable-and-comparator
 */
package com.mycompany.sec06;

import java.util.Arrays;

class Employee implements Comparable<Employee>
{
    private String name;
    private int age;
    private int salary;
    
    public Employee(String name, int age, int salary)
    {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getSalary() {
        return salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    
    public String toString()
    {
        return String.format("(%s, %d)", name, salary);
    }
    
    
    @Override
    public int compareTo(Employee employee) {
        return this.salary - employee.salary;
    }
}


public class SortEmployees {
    public static void main(String[] args) {
        
        Employee[] employees = new Employee[4];
        
        employees[0] = new Employee("Tom", 45, 80000);
        employees[1] = new Employee("Sam", 56, 75000);
        employees[2] = new Employee("Alex", 30, 120000);
        employees[3] = new Employee("Peter", 25, 60000);
        
        System.out.println("Before sorting: " + Arrays.toString(employees));
        
        Arrays.sort(employees);
        
        System.out.println("After sorting: " + Arrays.toString(employees));

    }
}
