/******************************************************************************

float number correct
*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		float num = 19.98f;
		System.out.println(num);
		
		System.out.println(((Object)num).getClass().getName());
	}
}
