/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author CEHVAREE
 */
public class MapDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Map<String, Color> favoriteColors = new HashMap<String, Color>();
        favoriteColors.put("Juliet", Color.BLUE);
        favoriteColors.put("Romeo", Color.GREEN);
        favoriteColors.put("Adam", Color.RED);
        favoriteColors.put("Eve", Color.BLUE);
        
        Set<String> keySet = favoriteColors.keySet();
        for (String key : keySet)
        {
            Color value = favoriteColors.get(key);
            System.out.println(key + " : " + value);
        }
    }
}
