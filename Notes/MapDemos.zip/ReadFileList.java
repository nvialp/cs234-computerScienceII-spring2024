/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author CEHVAREE
 */
public class ReadFileList {

    /**
     * Method to add a new element to the Directory
     * The key is the name, the value is an object Person
     * @param directory
     * @param file
     */
    public static void addToDirectory(Map directory, String file) throws FileNotFoundException, IOException
    {
       
        String line = "";
        BufferedReader br = new BufferedReader(new FileReader(file));
        while((line=br.readLine())!= null)
        {
            ArrayList<Object> list = new ArrayList<>();
            String[] person = line.split(",");
            System.out.println("[INFO] Adding to the directory:");
            System.out.println("\t"+person[0]+","+person[1]+","+person[2]);
            
            list.add(person[0]);
            list.add(person[1]);
            list.add(Integer.parseInt(person[2]));
            directory.put(person[0], list);
        }
    }
    
    /*
    * Method to print the whole directory
    * @param directory 
    */
    public static void printDirectory(Map directory)
    {
        System.out.println("\n[INFO] Printing the Directory"); 
        for (Object key : directory.keySet())
        {
            System.out.println(directory.get(key));
            
        }
    }
    
    public static void searchDirectory(String name, Map directory)
    {
        System.out.println("\n[INFO]Searching for: " + name);
        
        if (directory.containsKey(name))
        {
            ArrayList<Object> result = (ArrayList<Object>) directory.get(name);
            System.out.println("\t" +result);
            System.out.println("\tName: " + result.get(0) + 
                                ", Country: " + result.get(1) +
                                ", Height: " + result.get(2));
        }
        else
        {
            System.out.println("\t[INFO]This name does not exist.");
        }      
    }
    
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
       
        Map<String, ArrayList> directory = new HashMap<>();
        
        addToDirectory(directory, "data.csv");
        printDirectory(directory);
        searchDirectory("John", directory);
        searchDirectory("No name", directory);
    }
    
}
