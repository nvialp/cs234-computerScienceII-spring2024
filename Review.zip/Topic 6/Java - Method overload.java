public class Main
{
	
   static int addNumbers(int x, int y) 
   {
      return x + y;
    }

    static double addNumbers(double x, double y) 
    {
      return x + y;
    }
    
    static int addNumbers(int x, int y, int z) 
    {
      return x + y + z;
    }
    
    public static void main(String[] args)
    {
      int num1 = addNumbers(4,5);
      double num2 = addNumbers(4.5, 7.4);
      int num3 = addNumbers(2,6,5);
      System.out.println("2 ints: " + num1);
      System.out.println("2 doubles: " + num2);
      System.out.println("3 ints: " + num3);
    }
}