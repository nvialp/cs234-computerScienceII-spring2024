/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mapdemo;
import java.util.*;
/**
 *
 * @author CEHVAREE
 */
public class MapDemoIterator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<Integer, String>();
        
        map.put(100, "Eduardo");
        map.put(101, "Luis");
        map.put(102, "John");
        
        Set set = map.entrySet();
        Iterator itr = set.iterator();
        while(itr.hasNext())
        {
            // Converting to Map.Entry to get key and values separately
            Map.Entry m = (Map.Entry)itr.next();
            System.out.println(m.getKey() + " " + m.getValue());
        }
    }
    
}
