/******************************************************************************

arithmetics division

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
		int number1 = 45;
		int number2 = 246;
		
		int number = number1;
		if ((number % 2) == 0)
		{
		    System.out.println("Quotient: "+ number/2 +" Remainder: " + number%2);
		    System.out.println(number + " is even");
		}
		else
		{
		    System.out.println("Quotient: "+ number/2 +" Remainder: " + number%2);
		    System.out.println(number + " is odd");
		}
	}
}

